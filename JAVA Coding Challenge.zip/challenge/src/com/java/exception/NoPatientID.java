package com.java.exception;

public class NoPatientID extends RuntimeException {
    public NoPatientID(String message) {
        super(message);
    }
}
