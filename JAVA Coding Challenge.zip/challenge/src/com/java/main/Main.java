package com.java.main;

import com.java.dao.*;
import com.java.entity.*;
import com.java.exception.*;
import com.java.util.*;

import java.util.List;
import java.util.Scanner;

import java.sql.Connection;
import java.sql.SQLException;

public class Main 
{

    private static final ServiceInterface Service = new ServiceClass();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) 
    {
        try (Connection connection = DBConnUtil.getConnection()) 
        {
            System.out.println("Connected to database successfully\n");
            
            while (true) 
            {
                System.out.println("Welcome to Hospital Management System");
                System.out.println("1. Schedule Appointment");
                System.out.println("2. Update Appointment");
                System.out.println("3. Cancel Appointment");
                System.out.println("4. View Doctor Appointments");
                System.out.println("5. View Patient Appointments");
                System.out.println("6. Exit \n");
                System.out.print("Enter your choice: \n");
                int choice = scanner.nextInt();
                scanner.nextLine();

                switch (choice) 
                {
                    case 1:
                        scheduleAppointment();
                        break;
                    case 2:
                        updateAppointment();
                        break;
                    case 3:
                        cancelAppointment();
                        break;
                    case 4:
                        viewAppointmentsForDoctor();
                        break;
                    case 5:
                    	viewAppointmentsForPatient();
                        break;
                    case 6:
                        System.out.println("Exiting \n");
                        System.exit(0);
                    default:
                        System.out.println("Invalid choice \n");
                }
            }
        } 
        catch (SQLException e) 
        {
            System.out.println("Failed to connect to the database: " + e.getMessage()+" \n");
        }
    }

    private static void scheduleAppointment() throws SQLException, NoPatientID
    {
        System.out.println("Scheduling Appointment");

        System.out.print("Enter Patient ID: ");
        int patientId = scanner.nextInt();
        scanner.nextLine(); 
        
        System.out.print("Enter Doctor ID: ");
        int doctorId = scanner.nextInt();
        scanner.nextLine(); 

        System.out.print("Enter Appointment Date (YYYY-MM-DD): ");
        String appointmentDate = scanner.nextLine();

        System.out.print("Enter Description: ");
        String description = scanner.nextLine();

        
        Appointment appointment = new Appointment(0, patientId, doctorId, appointmentDate, description);

        
        boolean success = Service.scheduleAppointment(appointment);

        if (success) 
        {
            System.out.println("Appointment scheduled \n");
        } 
        else 
        {
            System.out.println("Failed to schedule \n");
        }
    }


    private static void updateAppointment() throws SQLException , NoPatientID
    {
        System.out.println("Updating Appointment");


        System.out.print("Enter Appointment ID: ");
        int appointmentId = scanner.nextInt();
        scanner.nextLine(); 
        try 
        {
            Appointment existingAppointment = Service.getAppointmentById(appointmentId);
            if (existingAppointment != null) {
                System.out.println("Enter new details for the appointment:");
                System.out.print("Enter Patient ID: ");
                int patientId = scanner.nextInt();
                scanner.nextLine();

                System.out.print("Enter Doctor ID: ");
                int doctorId = scanner.nextInt();
                scanner.nextLine(); 

                System.out.print("Enter Appointment Date (YYYY-MM-DD): ");
                String appointmentDate = scanner.nextLine();

                System.out.print("Enter Description: ");
                String description = scanner.nextLine();

                Appointment updatedAppointment = new Appointment(appointmentId, patientId, doctorId, appointmentDate, description);

                boolean success = Service.updateAppointment(updatedAppointment);

                if (success) 
                {
                    System.out.println("Appointment updated \n");
                } else 
                {
                    System.out.println("Failed to update \n");
                }
            } 
            else 
            {
                System.out.println("Appointment with ID " + appointmentId + " not found."+"\n");
            }
        } 
        catch (NoPatientID e) 
        {
            System.out.println(e.getMessage());
        }
    }


    private static void cancelAppointment() throws SQLException 
    {
        System.out.println("Canceling Appointment");
        
        System.out.print("Enter Appointment ID: ");
        int appointmentId = scanner.nextInt();
        scanner.nextLine(); 
        
        try 
        {
            Appointment existingAppointment = Service.getAppointmentById(appointmentId);
            if (existingAppointment != null) 
            {

                boolean done = Service.cancelAppointment(appointmentId);
                if (done) 
                {
                    System.out.println("Appointment with ID " + appointmentId + " canceled successfully \n");
                } 
                else 
                {
                    System.out.println("Failed to cancel \n");
                }
            } 
            else 
            {
                System.out.println("Appointment with ID " + appointmentId + " not found." +"\n");
            }
        } 
        catch (NoPatientID e) 
        {
            System.out.println(e.getMessage());
        }
    }


    private static void viewAppointmentsForPatient() throws SQLException 
    {
        System.out.print("Enter Patient ID: ");
        int patientId = scanner.nextInt();
        scanner.nextLine(); 
        try 
        {
            List<Appointment> appointments = Service.getAppointmentsForPatient(patientId);
            if (appointments.isEmpty()) {
                System.out.println("No appointments found for patient ID " + patientId);
            } 
            else 
            {
                System.out.println("Appointments for Patient ID " + patientId + ":");
                for (Appointment appointment : appointments) 
                {
                    System.out.println(appointment);
                }
            }
        } 
        catch (NoPatientID e) 
        {
            System.out.println(e.getMessage());
        }
    }

    private static void viewAppointmentsForDoctor() throws SQLException 
    {
        System.out.println("Viewing Appointments for Doctor");

        System.out.print("Enter Doctor ID: ");
        int doctorId = scanner.nextInt();
        scanner.nextLine(); 
        
        List<Appointment> appointments = Service.getAppointmentsForDoctor(doctorId);

        if (appointments.isEmpty()) 
        {
            System.out.println("No appointments found for Doctor ID " + doctorId);
        } 
        else 
        {
            System.out.println("Appointments for Doctor ID " + doctorId + ":");
            for (Appointment appointment : appointments) 
            {
                System.out.println(appointment);
            }
        }
    }
}


